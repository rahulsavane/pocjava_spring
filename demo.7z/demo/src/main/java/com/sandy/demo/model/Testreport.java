package com.sandy.demo.model;

import java.io.Serializable;
import javax.persistence.*;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.util.Date;
import java.util.List;


/**
 * The persistent class for the testreport database table.
 * 
 */
@Entity
@Table(name="Testreport")
@EntityListeners(AuditingEntityListener.class)
public class Testreport implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int testID;

	private String appName;

	private String backend;

	private String backendEnvironment;

	private String deliveryType;

	private String drSheetId;

	private String env;

	private String intakeName;

	private String priority;

	private String prjManager;

	private String releaseNo;

	private String runPhase;

	private String testingPhase;

	@Temporal(TemporalType.DATE)
	private Date testPhEndDate;

	@Temporal(TemporalType.DATE)
	private Date testPhStartDate;

	//bi-directional many-to-one association to Drfile
	@OneToMany(mappedBy="testreport")
	private List<Drfile> drfiles;

	//bi-directional many-to-one association to Project
	@ManyToOne
	@JoinColumn(name="projectId")
	private Project project;

	public Testreport() {
	}

	public int getTestID() {
		return this.testID;
	}

	public void setTestID(int testID) {
		this.testID = testID;
	}

	public String getAppName() {
		return this.appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getBackend() {
		return this.backend;
	}

	public void setBackend(String backend) {
		this.backend = backend;
	}

	public String getBackendEnvironment() {
		return this.backendEnvironment;
	}

	public void setBackendEnvironment(String backendEnvironment) {
		this.backendEnvironment = backendEnvironment;
	}

	public String getDeliveryType() {
		return this.deliveryType;
	}

	public void setDeliveryType(String deliveryType) {
		this.deliveryType = deliveryType;
	}

	public String getDrSheetId() {
		return this.drSheetId;
	}

	public void setDrSheetId(String drSheetId) {
		this.drSheetId = drSheetId;
	}

	public String getEnv() {
		return this.env;
	}

	public void setEnv(String env) {
		this.env = env;
	}

	public String getIntakeName() {
		return this.intakeName;
	}

	public void setIntakeName(String intakeName) {
		this.intakeName = intakeName;
	}

	public String getPriority() {
		return this.priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public String getPrjManager() {
		return this.prjManager;
	}

	public void setPrjManager(String prjManager) {
		this.prjManager = prjManager;
	}

	public String getReleaseNo() {
		return this.releaseNo;
	}

	public void setReleaseNo(String releaseNo) {
		this.releaseNo = releaseNo;
	}

	public String getRunPhase() {
		return this.runPhase;
	}

	public void setRunPhase(String runPhase) {
		this.runPhase = runPhase;
	}

	public String getTestingPhase() {
		return this.testingPhase;
	}

	public void setTestingPhase(String testingPhase) {
		this.testingPhase = testingPhase;
	}

	public Date getTestPhEndDate() {
		return this.testPhEndDate;
	}

	public void setTestPhEndDate(Date testPhEndDate) {
		this.testPhEndDate = testPhEndDate;
	}

	public Date getTestPhStartDate() {
		return this.testPhStartDate;
	}

	public void setTestPhStartDate(Date testPhStartDate) {
		this.testPhStartDate = testPhStartDate;
	}

	public List<Drfile> getDrfiles() {
		return this.drfiles;
	}

	public void setDrfiles(List<Drfile> drfiles) {
		this.drfiles = drfiles;
	}

	public Drfile addDrfile(Drfile drfile) {
		getDrfiles().add(drfile);
		drfile.setTestreport(this);

		return drfile;
	}

	public Drfile removeDrfile(Drfile drfile) {
		getDrfiles().remove(drfile);
		drfile.setTestreport(null);

		return drfile;
	}

	public Project getProject() {
		return this.project;
	}

	public void setProject(Project project) {
		this.project = project;
	}

}