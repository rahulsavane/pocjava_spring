package com.sandy.demo;


import java.util.LinkedList;
import java.util.List;

import javax.validation.Valid;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.sandy.demo.dao.DrFileDao;
import com.sandy.demo.dao.ProjectDao;
import com.sandy.demo.dao.TestReportDao;
import com.sandy.demo.model.Drfile;
import com.sandy.demo.model.Project;
import com.sandy.demo.model.Testreport;
import com.sandy.demo.payload.UploadFileResponse;
import com.sandy.demo.service.DBFileStorageService;

import ch.qos.logback.classic.Logger;


@RestController
public class HelloWorld {

	private HelloService s1 = new HelloService();
	private static final Logger LOGGER = (Logger) LoggerFactory.getLogger(HelloWorld.class);
	@RequestMapping("/hello")
	public String Hello()
	{
		return s1.HelloService();
	}
	
	
	@Autowired
	TestReportDao testReportDao;
		
	@Autowired
	ProjectDao projectDao;
	
	@Autowired
	DrFileDao drfileDao;
	
	@Autowired
	private DBFileStorageService dbFileStorageService;
	
	@CrossOrigin(origins = "*")
	@PostMapping(path="/saveTestReport",consumes = "application/json",produces = "application/json")
	public ResponseEntity createTestReport(@Valid @RequestBody Testreport testreport)
	{
		LOGGER.info("createTestReport", "Start");
		testreport.setDrfiles(new LinkedList<Drfile>());
		testreport.addDrfile(drfileDao.getDrFileById("d70f2b40-df07-40d9-a93a-65d47d56edff").get());
		testreport.setProject(projectDao.getProjectById(1).get());
		//return testReportDao.save(testreport);
		return ResponseEntity.ok().build(); 
	}
	
	@GetMapping("/getProject")
	public List<Project> getAllProject()
	{
		return projectDao.getAll();
	}
	
	@CrossOrigin(origins = "*")
	@GetMapping("/getProjectById")
	public Project getProjectById(@RequestParam("projectId") int projectId)
	{
		return projectDao.getProjectById(projectId).get();
	}
	
	@CrossOrigin(origins = "*")
    @PostMapping("/uploadFile")
    public UploadFileResponse uploadFile(@RequestParam("file") MultipartFile file) {
        Drfile dbFile = dbFileStorageService.storeFile(file);

        String fileDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath()
                .path("/downloadFile/")
                .path(dbFile.getId())
                .toUriString();

        return new UploadFileResponse(dbFile.getFileName(), fileDownloadUri,
                file.getContentType(), file.getSize());
    }}

class HelloService{
	
	public String HelloService() {
		return "Hello Spring Boot World!!";
	}
}