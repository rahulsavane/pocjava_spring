package com.sandy.demo.repository;


import org.springframework.data.repository.CrudRepository;

import com.sandy.demo.model.Drfile;

public interface DrFileRepository extends CrudRepository<Drfile, String> {

}
