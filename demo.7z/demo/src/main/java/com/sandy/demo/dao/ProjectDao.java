package com.sandy.demo.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sandy.demo.model.Project;
import com.sandy.demo.repository.ProjectRepository;

@Service
public class ProjectDao {

	@Autowired
	ProjectRepository projectRepository;
	
	//SAVE
	public Project save(Project project)
	{
		return projectRepository.save(project);
	}
	
	
	//FIND ALL
	public List<Project> getAll()
	{
		return (List<Project>) projectRepository.findAll();
	}
	//FIND BY ID
	public Optional<Project> getProjectById(int prjId)
	{
		return projectRepository.findById(prjId);
	}
	//DELETE 
	
	
	
}
