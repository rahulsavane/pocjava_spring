package com.sandy.demo.repository;


import org.springframework.data.repository.CrudRepository;

import com.sandy.demo.model.Project;

public interface ProjectRepository extends CrudRepository<Project, Integer> {

}
