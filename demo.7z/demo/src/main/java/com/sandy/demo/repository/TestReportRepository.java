package com.sandy.demo.repository;


import org.springframework.data.repository.CrudRepository;


import com.sandy.demo.model.Testreport;

public interface TestReportRepository extends CrudRepository<Testreport, Long> {

}
