package com.sandy.demo.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sandy.demo.model.Drfile;
import com.sandy.demo.repository.DrFileRepository;

@Service
public class DrFileDao {

	@Autowired
	DrFileRepository drFileRepository;
	
	//SAVE
	public Drfile save(Drfile file)
	{
		return drFileRepository.save(file);
	}
	
	
	//FIND ALL
	public List<Drfile> getAll()
	{
		return (List<Drfile>) drFileRepository.findAll();
	}
	//FIND BY ID
	public Optional<Drfile> getDrFileById(String prjId)
	{
		return drFileRepository.findById(prjId);
	}
	//DELETE 
	
	
	
}
