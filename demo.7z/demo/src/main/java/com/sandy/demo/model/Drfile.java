package com.sandy.demo.model;

import java.io.Serializable;
import javax.persistence.*;

import org.hibernate.annotations.GenericGenerator;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the drfile database table.
 * 
 */
@Entity
@Table(name="Drfile")
@EntityListeners(AuditingEntityListener.class)
public class Drfile implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(generator = "uuid")
    @GenericGenerator(name = "uuid", strategy = "uuid2")
	private String id;

	@Lob
	private byte[] file;

	private String fileName;

	private String fileType;

	@Lob
	private byte[] originalMedia;

	//bi-directional many-to-one association to Testreport
	@JsonIgnore
	@ManyToOne
	@JoinColumn(name="testRecId")
	private Testreport testreport;

	public Drfile() {
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public byte[] getFile() {
		return this.file;
	}

	public void setFile(byte[] file) {
		this.file = file;
	}

	public String getFileName() {
		return this.fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFileType() {
		return this.fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public byte[] getOriginalMedia() {
		return this.originalMedia;
	}

	public void setOriginalMedia(byte[] originalMedia) {
		this.originalMedia = originalMedia;
	}

	public Testreport getTestreport() {
		return this.testreport;
	}

	public void setTestreport(Testreport testreport) {
		this.testreport = testreport;
	}

}