package com.sandy.demo.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sandy.demo.model.Testreport;
import com.sandy.demo.repository.TestReportRepository;

@Service
public class TestReportDao {

	@Autowired
	TestReportRepository testReportRepository;
	
	//SAVE
	public Testreport save(Testreport testreport)
	{
		return testReportRepository.save(testreport);
	}
	
	
	//FIND ALL
	public List<Testreport> getAll()
	{
		return (List<Testreport>) testReportRepository.findAll();
	}
	//FIND BY ID
	public Optional<Testreport> getTestReportById(Long empId)
	{
		return testReportRepository.findById(empId);
	}
	//DELETE 
	
	
	
}
