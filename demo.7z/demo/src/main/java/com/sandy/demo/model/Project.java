package com.sandy.demo.model;

import java.io.Serializable;
import javax.persistence.*;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.List;


/**
 * The persistent class for the project database table.
 * 
 */
@Entity
@Table(name="Project")
@EntityListeners(AuditingEntityListener.class)
public class Project implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	private int prjId;

	private String projectName;

	//bi-directional many-to-one association to Testreport
	@JsonIgnore
	@OneToMany(mappedBy="project")
	private List<Testreport> testreports;

	public Project() {
	}


	public int getPrjId() {
		return this.prjId;
	}

	public void setPrjId(int prjId) {
		this.prjId = prjId;
	}

	public String getProjectName() {
		return this.projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public List<Testreport> getTestreports() {
		return this.testreports;
	}

	public void setTestreports(List<Testreport> testreports) {
		this.testreports = testreports;
	}

	public Testreport addTestreport(Testreport testreport) {
		getTestreports().add(testreport);
		testreport.setProject(this);

		return testreport;
	}

	public Testreport removeTestreport(Testreport testreport) {
		getTestreports().remove(testreport);
		testreport.setProject(null);

		return testreport;
	}

}